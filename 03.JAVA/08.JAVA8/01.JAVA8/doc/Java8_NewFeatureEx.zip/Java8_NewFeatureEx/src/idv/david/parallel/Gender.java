package idv.david.parallel;

public enum Gender {
	MALE, FEMALE
}
