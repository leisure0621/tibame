package idv.david.methodenhance;

public class RulesTest {

    public static void main(String[] args) {
        D d = new D();
        d.m();
    }
    
}
