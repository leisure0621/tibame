package idv.david.lambda.builtintype;

public enum Color {
	BLACK, RED, BLUE
}
