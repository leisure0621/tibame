package idv.david.lambda;

public enum Color {
	BLACK, RED, BLUE
}
