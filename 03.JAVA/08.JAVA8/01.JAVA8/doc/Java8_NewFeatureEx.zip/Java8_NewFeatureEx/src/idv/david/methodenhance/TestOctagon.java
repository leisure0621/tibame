package idv.david.methodenhance;

public class TestOctagon {

	public static void main(String[] args) {
		
		// Amazing ^^
		System.out.println(Octagon.cornerCount());
	}

}
