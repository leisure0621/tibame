package idv.david.methodenhance;

public interface Octagon {
	public static int cornerCount() {
		return 8;
	}

}
