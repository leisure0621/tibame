package idv.david.lambda.additional;

public enum Gender {
	MALE, FEMALE
}
