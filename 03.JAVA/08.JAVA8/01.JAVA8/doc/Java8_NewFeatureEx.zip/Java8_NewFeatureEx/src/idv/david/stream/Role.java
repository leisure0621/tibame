package idv.david.stream;

public enum Role {
	STAFF, MANAGER, EXECUTIVE
}
