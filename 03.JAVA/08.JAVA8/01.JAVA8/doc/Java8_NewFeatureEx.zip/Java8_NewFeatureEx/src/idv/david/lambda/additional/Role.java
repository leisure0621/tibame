package idv.david.lambda.additional;

public enum Role {
	STAFF, MANAGER, EXECUTIVE
}
