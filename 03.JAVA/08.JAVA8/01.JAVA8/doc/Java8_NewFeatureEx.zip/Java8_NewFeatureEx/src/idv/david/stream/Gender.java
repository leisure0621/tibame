package idv.david.stream;

public enum Gender {
	MALE, FEMALE
}
