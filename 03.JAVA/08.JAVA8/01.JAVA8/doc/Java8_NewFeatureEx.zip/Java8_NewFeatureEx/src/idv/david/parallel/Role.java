package idv.david.parallel;

public enum Role {
	STAFF, MANAGER, EXECUTIVE
}
