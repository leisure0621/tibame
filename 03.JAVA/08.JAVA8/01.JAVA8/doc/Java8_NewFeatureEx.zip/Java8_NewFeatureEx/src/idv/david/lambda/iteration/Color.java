package idv.david.lambda.iteration;

public enum Color {
	BLACK, RED, BLUE
}
