package albert;

public class Car {
	public int getWheels() {
		return 4;
	}
}
