package mycar;

public interface Engine {
	int start();
}
